﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

[System.Serializable]
public class Line
{
    [Header("New Line ---------------------------------------")]
    public bool hasEvent;
    public int eventIndex;
    public float typeIntervalTime = -1;
    public TMP_FontAsset font;
    public string name;
    [TextArea(4, 3)]
    public string speech;
}
