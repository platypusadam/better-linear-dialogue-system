﻿using System.Collections.Generic;
using System.Collections;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using System;

public class Dialogue
{
    public DialogueEventHolderBase dialogueEvents;
    public ConversationInfo convo;
    public GameObject UIparent;
    public GameObject nameText;
    public GameObject speechText;
    public GameObject panel;
    private NPC _thisNPC;

    public Queue<Line> lines;
    private Line _currentLine;

    public Dialogue(ConversationInfo conversation, GameObject myUIparent, GameObject nameUI, GameObject speechUI, GameObject panelUI, NPC thisNPC)
    {
        convo = conversation;
        UIparent = myUIparent;
        nameText = nameUI;
        speechText = speechUI;
        panel = panelUI;
        _thisNPC = thisNPC;
        if(_thisNPC.dialogueEvents != null)
            dialogueEvents = _thisNPC.dialogueEvents;
    }

    public void DialogueInitiate()
    {
        //  Make NPC isTalking boolean true
        _thisNPC.isTalking = true;

        //  Add each line from the conversation to the Queue of lines
        lines = new Queue<Line>();
        foreach (Line line in convo.lines)
        {
            lines.Enqueue(line);
        }

        //  Make the UI active, let animation play
        UIparent.SetActive(true);

        //  Set the first line
        _currentLine = lines.Dequeue();

        //  Set the font
        if (_currentLine.font != null)
        {
            speechText.GetComponent<TextMeshProUGUI>().font = _currentLine.font;
        }
        else
            speechText.GetComponent<TextMeshProUGUI>().font = _thisNPC.defaultFont;

        //  Set speechtext's and nametext's text
        if (_currentLine != null)
        {
            nameText.GetComponent<TextMeshProUGUI>().text = _currentLine.name;
            speechText.GetComponent<TextMeshProUGUI>().text = _currentLine.speech;
        }

        //Reset teletype
        _thisNPC.StopCoroutine(_thisNPC.myDialogue.TeleType());
        _thisNPC.StartCoroutine(_thisNPC.myDialogue.TeleType());

        //  Invoke line's event
        if (_currentLine.hasEvent == true)
        {
            if (dialogueEvents != null)
            {
                try
                {
                    if (_currentLine.eventIndex <= dialogueEvents.eventList.Count)
                        dialogueEvents.eventList[_currentLine.eventIndex].Invoke();
                }
                catch
                {
                    Debug.LogWarning("The Dialogue event holder hasn't got an event for the current line!     Conversation- " + convo.name + ".");
                }
            }
        }
    }

    public void DialogueUpdate()
    {
        speechText.GetComponent<TextMeshProUGUI>().ForceMeshUpdate();
    }

    public void DialogueContinue()
    {
        //Reset teletype
        _thisNPC.StopCoroutine(_thisNPC.myDialogue.TeleType());
        _thisNPC.StartCoroutine(_thisNPC.myDialogue.TeleType());

        //  If more lines left
        if (lines.Count > 0)
        {
            _currentLine = lines.Dequeue();

            //  Invoke line's event
            if (_currentLine.hasEvent == true)
            {
                if (dialogueEvents != null)
                {
                    try
                    {
                        if (_currentLine.eventIndex <= dialogueEvents.eventList.Count)
                            dialogueEvents.eventList[_currentLine.eventIndex].Invoke();
                    }
                    catch
                    {
                        Debug.LogWarning("The Dialogue event holder hasn't got an event for the current line!     Conversation- " + convo.name + ".");
                    }
                }
            }
        }

        //  Set the font
        if (_currentLine.font != null)
        {
            speechText.GetComponent<TextMeshProUGUI>().font = _currentLine.font;
        }
        else
            speechText.GetComponent<TextMeshProUGUI>().font = _thisNPC.defaultFont;

        //  Set speechtext's and nametext's text
        if (_currentLine != null)
        {
            nameText.GetComponent<TextMeshProUGUI>().text = _currentLine.name;
            speechText.GetComponent<TextMeshProUGUI>().text = _currentLine.speech;
        }
    }

    public void DialogueEnd()
    {
        UIparent.SetActive(false);
        _thisNPC.isTalking = false;
        speechText.GetComponent<TextMeshProUGUI>().text = "";
        nameText.GetComponent<TextMeshProUGUI>().text = "";
        if (_thisNPC.conversationNumber < _thisNPC.myConversations.Length - 1)
        {
            _thisNPC.conversationNumber += 1;
        }
    }


    public IEnumerator TeleType()
    {
        TextMeshProUGUI tmp = speechText.GetComponent<TextMeshProUGUI>();
        tmp.maxVisibleCharacters = 0;
        for (int i = 0; i <= tmp.text.Length; i++)
        {
            tmp.maxVisibleCharacters++;
            if (_currentLine.typeIntervalTime > 0)
                yield return new WaitForSeconds(_currentLine.typeIntervalTime);
            else
                yield return new WaitForSeconds(_thisNPC.defaultTypeIntervalTime);
        }
    }
}
