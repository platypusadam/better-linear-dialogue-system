﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class DialogueEventHolderBase : MonoBehaviour
{
    public List<UnityEvent> eventList;
    public void SayString(string str)
    {
        print(str);
    }
}
