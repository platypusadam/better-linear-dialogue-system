﻿using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class NPC : MonoBehaviour
{
    public ConversationInfo[] myConversations;
    [HideInInspector] public int conversationNumber;
    [HideInInspector] public ConversationInfo currentConversation;
    public Dialogue myDialogue;
    public DialogueEventHolderBase dialogueEvents;
    [HideInInspector] public bool isTalking;
    public TMP_FontAsset defaultFont;
    protected bool isInRangeToTalk;

    public float defaultTypeIntervalTime;
    public GameObject UIparent;
    public GameObject nameText;
    public GameObject speechText;
    public GameObject panel;

    
    protected NPCcontrols controls;  //  Set the controls

    protected void Update()
    {
        if (myDialogue != null)
            myDialogue.DialogueUpdate();  //  Set the UI to values according to the active conversation
    }
    protected void Awake()
    {
        conversationNumber = 0;  //  Set the conversation to the first in the array
        controls = new NPCcontrols();  //  Set the controls
        controls.NPC.Interact.performed += _ => Interact();  //  Give the controls the Interact function
    }

    protected virtual void RefreshConversation()
    {
        if (conversationNumber <= myConversations.Length - 1)  //  Only change the conversation if the conversationNumber is within the size of the array "myConversations"
            currentConversation = myConversations[conversationNumber];
        myDialogue = new Dialogue(currentConversation, UIparent, nameText, speechText, panel, this);  //  Instantiate a new Dialogue
    }
    private void OnEnable()  //  Enable controls
    {
        controls.Enable();
    }
    private void OnDisable()  //  Disable controls
    {
        controls.Disable();
    }


    protected virtual void Interact()  //  Interact from NPC controls asset. Currently "E"
    {
        if (isInRangeToTalk)
        {
            if (isTalking == false)  //  If not in a conversation, RefreshConversation and start the conversation
            {
                RefreshConversation();
                myDialogue.DialogueInitiate();
            }
            else if (isTalking == true)  //  If in a conversation, check if on the lsat line. If so, end conversatoin. Otherwise, continue conversation.
            {
                //  If line is finished typing
                if (speechText.GetComponent<TextMeshProUGUI>().maxVisibleCharacters >= speechText.GetComponent<TextMeshProUGUI>().text.Length)
                {
                    if (myDialogue.lines.Count < 1)
                    {
                        myDialogue.DialogueEnd();  //  Sets UI to inactive, +1s the conversation number, sets "isTalking" bool to false
                    }
                    else
                    {
                        myDialogue.DialogueContinue();  //  Dequeues the Dialogue's "lines" queue, and sets the current line's value to that
                    }
                }
                else
                {
                    speechText.GetComponent<TextMeshProUGUI>().maxVisibleCharacters = speechText.GetComponent<TextMeshProUGUI>().text.Length;
                    StopCoroutine(myDialogue.TeleType());
                }
            }
        }
    }
}
