// GENERATED AUTOMATICALLY FROM 'Assets/Input/NPCcontrols.inputactions'

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

public class @NPCcontrols : IInputActionCollection, IDisposable
{
    public InputActionAsset asset { get; }
    public @NPCcontrols()
    {
        asset = InputActionAsset.FromJson(@"{
    ""name"": ""NPCcontrols"",
    ""maps"": [
        {
            ""name"": ""NPC"",
            ""id"": ""22197b11-6e14-490d-9aa5-153bbce9aaf5"",
            ""actions"": [
                {
                    ""name"": ""Interact"",
                    ""type"": ""Button"",
                    ""id"": ""1a8090a3-bd27-46b0-87c3-dbf9c74cf42a"",
                    ""expectedControlType"": ""Button"",
                    ""processors"": """",
                    ""interactions"": """"
                }
            ],
            ""bindings"": [
                {
                    ""name"": """",
                    ""id"": ""a93fb2fd-e416-4a2c-be32-a17191e578ff"",
                    ""path"": ""<Keyboard>/e"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Interact"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                }
            ]
        }
    ],
    ""controlSchemes"": []
}");
        // NPC
        m_NPC = asset.FindActionMap("NPC", throwIfNotFound: true);
        m_NPC_Interact = m_NPC.FindAction("Interact", throwIfNotFound: true);
    }

    public void Dispose()
    {
        UnityEngine.Object.Destroy(asset);
    }

    public InputBinding? bindingMask
    {
        get => asset.bindingMask;
        set => asset.bindingMask = value;
    }

    public ReadOnlyArray<InputDevice>? devices
    {
        get => asset.devices;
        set => asset.devices = value;
    }

    public ReadOnlyArray<InputControlScheme> controlSchemes => asset.controlSchemes;

    public bool Contains(InputAction action)
    {
        return asset.Contains(action);
    }

    public IEnumerator<InputAction> GetEnumerator()
    {
        return asset.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public void Enable()
    {
        asset.Enable();
    }

    public void Disable()
    {
        asset.Disable();
    }

    // NPC
    private readonly InputActionMap m_NPC;
    private INPCActions m_NPCActionsCallbackInterface;
    private readonly InputAction m_NPC_Interact;
    public struct NPCActions
    {
        private @NPCcontrols m_Wrapper;
        public NPCActions(@NPCcontrols wrapper) { m_Wrapper = wrapper; }
        public InputAction @Interact => m_Wrapper.m_NPC_Interact;
        public InputActionMap Get() { return m_Wrapper.m_NPC; }
        public void Enable() { Get().Enable(); }
        public void Disable() { Get().Disable(); }
        public bool enabled => Get().enabled;
        public static implicit operator InputActionMap(NPCActions set) { return set.Get(); }
        public void SetCallbacks(INPCActions instance)
        {
            if (m_Wrapper.m_NPCActionsCallbackInterface != null)
            {
                @Interact.started -= m_Wrapper.m_NPCActionsCallbackInterface.OnInteract;
                @Interact.performed -= m_Wrapper.m_NPCActionsCallbackInterface.OnInteract;
                @Interact.canceled -= m_Wrapper.m_NPCActionsCallbackInterface.OnInteract;
            }
            m_Wrapper.m_NPCActionsCallbackInterface = instance;
            if (instance != null)
            {
                @Interact.started += instance.OnInteract;
                @Interact.performed += instance.OnInteract;
                @Interact.canceled += instance.OnInteract;
            }
        }
    }
    public NPCActions @NPC => new NPCActions(this);
    public interface INPCActions
    {
        void OnInteract(InputAction.CallbackContext context);
    }
}
